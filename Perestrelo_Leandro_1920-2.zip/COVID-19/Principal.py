from Registro import Registro
from Estadisticas import Estadisticas

menu = "Ingrese 1 para modulo de registro \n" \
       "Ingrese 2 para modulo de estadisticas \n" \
       "Ingrese 3 para salir\n" \
       "Su opcion es: "



registro = Registro()
estadisticas = Estadisticas()


def main():                       # MENU PRINCIPAL
    opcion = 0
    while opcion != 3:
        opcion_str = str(input(menu))
        if opcion_str.isnumeric():
            opcion = int(opcion_str)
            if opcion == 1:
                registro.RegistrarPaciente()
            elif opcion == 2:
                estadisticas.modulo_estadisticas()
            elif opcion == 3:
                print("Gracias por usar COVID-19 Tracker")
            else:
                print("Opcion invalida, por favor vuelva a ingresar su opcion")
        else:
            print("Opcion invalida, por favor vuelva a ingresar su opcion")

main()