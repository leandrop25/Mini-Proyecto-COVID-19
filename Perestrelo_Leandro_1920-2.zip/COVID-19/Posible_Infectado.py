from Persona import Persona

class Posible_Infectado(Persona):

    def __init__(self, nombre, edad, direccion, ciudad, estado):   # PERSONAS POSIBLE INFECTADAS
        super(Posible_Infectado, self).__init__(nombre, edad)
        self.direccion = direccion
        self.ciudad = ciudad
        self.estado = estado
