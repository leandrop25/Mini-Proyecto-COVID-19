from Persona import Persona

class Infectado(Persona):

    def __init__(self, nombre, edad, direccion, ciudad, estado, medico):    # PERSONAS INFECTADAS
        super(Infectado, self).__init__(nombre, edad)
        self.direccion = direccion
        self.ciudad = ciudad
        self.estado = estado
        self.medico = medico
