import operator

import requests


class Estadisticas:
    def __init__(self):                                      # MENU DE ESTADISTICAS
        self.menu = "Ingrese 1 para buscar por pais \n" \
                    "Ingrese 2 para ver los 10 paises con mas infectados \n" \
                    "Ingrese 3 para ver los 10 paises con mas muertes \n" \
                    "Ingrese 4 para ver los 10 paises con mas recuperados \n" \
                    "Ingrese 5 para regresar al menu principal\n" \
                    "Su opcion es: "

    def consultar_api(self, pais=""):             # CODIGO API
        try:
            url = "https://covid-19-coronavirus-statistics.p.rapidapi.com/v1/stats"
            querystring = {"country": pais}
            headers = {
                'x-rapidapi-host': "covid-19-coronavirus-statistics.p.rapidapi.com",
                'x-rapidapi-key': "14e83b6069msh02f8bed3bbd89d7p1607f7jsnf94295c8df74"
            }

            response = requests.request("GET", url, headers=headers, params=querystring)
            return self.ordenar_por_pais(response.json()["data"]["covid19Stats"])

        except:
            print("Error al consultar el api")
            return []

    def ordenar_por_pais(self, data):               # ORDEN POR PAIS DE CASOS CONFIRMADOS, RECUPERADOS Y MUERTOS
        lista_paises = {}
        for ciudad in data:
            if ciudad["country"] in lista_paises:
                lista_paises[ciudad["country"]]["confirmed"] += ciudad["confirmed"]
                lista_paises[ciudad["country"]]["recovered"] += ciudad["recovered"]
                lista_paises[ciudad["country"]]["deaths"] += ciudad["deaths"]
            else:
                lista_paises[ciudad["country"]]={}
                lista_paises[ciudad["country"]]["country"] = ciudad["country"]
                lista_paises[ciudad["country"]]["confirmed"] = ciudad["confirmed"]
                lista_paises[ciudad["country"]]["recovered"] = ciudad["recovered"]
                lista_paises[ciudad["country"]]["deaths"] = ciudad["deaths"]
        return lista_paises.values()

    def buscador_pais(self):                        # BUSCADOR DE PAIS
        pais = str(input("Ingrese el pais que desea buscar, la primera letra tiene que ser en mayuscula y en ingles "))
        lista = self.consultar_api(pais)
        if len(pais) > 0 and len(lista) > 1:
            print("El pais no se encuentra")
        else:
            for country in lista:
                print("Pais: {}".format(country["country"]))
                print("Personas infectadas: {}".format(country["confirmed"]))
                print("Personas curadas: {}".format(country["recovered"]))
                print("Personas fallecidas: {}\n".format(country["deaths"]))

    def top10_infectados(self):                    # TOP 10 DE CASOS CONFIRMADOS
        lista = self.consultar_api()
        lista_ordenada = sorted(lista, key=operator.itemgetter("confirmed"), reverse=True)

        for pais in lista_ordenada[:10]:
            print("Pais: {} Infectados: {}".format(pais["country"], pais["confirmed"]))

    def top10_recuperados(self):                   # TOP 10 DE CASOS RECUPERADOS
        lista = self.consultar_api()
        lista_ordenada = sorted(lista, key=operator.itemgetter("recovered"), reverse=True)

        for pais in lista_ordenada[:10]:
            print("Pais: {} Recuperados: {}".format(pais["country"], pais["recovered"]))

    def top10_muertes(self):                       # TOP 10 DE CASOS MUERTOS
        lista = self.consultar_api()
        lista_ordenada = sorted(lista, key=operator.itemgetter("deaths"), reverse=True)

        for pais in lista_ordenada[:10]:
            print("Pais: {} Muertos: {}".format(pais["country"], pais["deaths"]))

    def modulo_estadisticas(self):                  # MODULO DE ESTADISTICAS
        opcion = 0
        while opcion != 5:
            opcion_str = str(input(self.menu))
            if opcion_str.isnumeric():
                opcion = int(opcion_str)
                if opcion == 1:
                    self.buscador_pais()
                elif opcion == 2:
                    self.top10_infectados()
                elif opcion == 3:
                    self.top10_muertes()
                elif opcion == 4:
                    self.top10_recuperados()
                elif opcion == 5:
                    print("")
                else:
                    print("Opcion invalida, por favor vuelva a ingresar su opcion")
            else:
                print("Opcion invalida, por favor vuelva a ingresar su opcion")
