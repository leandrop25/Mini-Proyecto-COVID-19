from Infectado import Infectado
from No_Infectado import No_Infectado
from Posible_Infectado import Posible_Infectado


class Registro():

    def __init__(self):           # MENU DE PREGUNTAS
        self.pacientes = []
        self.clasificacion_pacientes = {"No infectado": [], "En revision": [], "Posible infectado": [], "Infectado": []}
        self.lista_preguntas = ["Tienes secreciones nasales S/N \n",
                                "Tienes dolor de garganta S/N \n",
                                "Tienes tos S/N \n",
                                "Tienes fiebre S/N \n",
                                "Tienes dificultad para respirar S/N \n"]

    def RegistrarPaciente(self):                  # DATOS DEL PACIENTE
        nombre = str(input("Ingrese su nombre "))
        while not nombre.isalpha():
            print("Nombre invalido")
            nombre = str(input("Ingrese su nombre "))
        edad = 0
        while edad == 0:
            edad_str = str(input("Ingrese su edad "))
            if edad_str.isnumeric() and 0 <= int(edad_str) <= 120:
                edad = int(edad_str)
            else:
                print("Edad invalida")
        respuestas = self.preguntas()
        self.clasificar_paciente(nombre, edad, respuestas)


    def clasificar_paciente(self, nombre, edad, respuestas):   # CLASIFICACION DEL PACIENTE DEPENDE DE SUS SINTOMAS
        if respuestas == 0 or respuestas == 1:                       # PACIENTE NO INFECTADO
            if respuestas == 0:
                print("No tiene ningun sintoma del COVID-19")
                clasificacion = "No infectado"
            else:
                print("Esta en revision, ya que tiene un sintoma del COVID-19")
                clasificacion = "En revision"
            numero_telefono = 0
            while numero_telefono == 0:
                numero_telefono_str = str(input("Ingrese su numero de telefono"))
                if numero_telefono_str.isnumeric() and len(numero_telefono_str) == 11:
                    numero_telefono = int(numero_telefono_str)
                else:
                    print("Numero de telefono invalido")
            paciente = No_Infectado(nombre, edad, numero_telefono)
        elif 2 <= respuestas <= 4:                                    # PACIENTE POSIBLE INFECTADO
            print("Es un posible infectado, ya que tiene varios sintomas del COVID-19")
            estado = str(input("Ingrese el estado donde vive"))
            while not estado.isalpha():
                print("Estado invalido")
                estado = str(input("Ingrese el estado donde vive"))
            ciudad = str(input("Ingrese la ciudad donde vive"))
            while not ciudad.isalpha():
                print("Ciudad invalida")
                ciudad = str(input("Ingrese la ciudad donde vive"))
            direccion = str(input("Ingrese la direccion donde vive"))
            paciente = Posible_Infectado(nombre, edad, direccion, ciudad, estado)
            clasificacion ="Posible infectado"

        else:                                                         # PACIENTE INFECTADO
            print("Es un infectado, ya que tiene todos sintomas del COVID-19")
            estado = str(input("Ingrese el estado donde vive"))
            while not estado.isalpha():
                print("Estado invalido")
                estado = str(input("Ingrese el estado donde vive"))
            ciudad = str(input("Ingrese la ciudad donde vive"))
            while not ciudad.isalpha():
                print("Ciudad invalida")
                ciudad = str(input("Ingrese la ciudad donde vive"))
            direccion = str(input("Ingrese la direccion donde vive"))
            medico_tratante = str(input("Ingrese el nombre del medico tratante"))
            while not medico_tratante.isalpha():
                print("Nombre de medico invalido")
                medico_tratante = str(input("Ingrese el nombre del medico tratante"))
            paciente = Infectado(nombre,edad,direccion,ciudad,estado,medico_tratante)
            clasificacion = "Infectado"

        self.clasificacion_pacientes[clasificacion].append(paciente)
        self.pacientes.append(paciente)

    def preguntas(self):             # VALIDACION DE LAS RESPUESTAS DEL PACIENTE
        respuestas_afirmativas = 0
        for pregunta in self.lista_preguntas:
            respuesta = str(input(pregunta)).lower()
            while respuesta != "s" and respuesta != "n":
                respuesta = str(input("Respuesta invalida"))
            if respuesta == "s":
                respuestas_afirmativas += 1
        return respuestas_afirmativas


