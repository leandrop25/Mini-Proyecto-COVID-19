from Persona import Persona

class No_Infectado(Persona):

    def __init__(self, nombre, edad, telefono):                  # PERSONAS NO INFECTADAS
        super(No_Infectado, self).__init__(nombre, edad)
        self.telefono = telefono





