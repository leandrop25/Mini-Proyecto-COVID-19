class Persona:

    def __init__(self, nombre, edad):            # PERSONAS
        self.nombre = nombre
        self. edad = edad
